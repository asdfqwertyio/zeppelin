 ____  ____  ____  ____  ____  __    __  __ _ 
(__  )(  __)(  _ \(  _ \(  __)(  )  (  )(  ( \
 / _/  ) _)  ) __/ ) __/ ) _) / (_/\ )( /    /
(____)(____)(__)  (__)  (____)\____/(__)\_)__)

## Introduction

Zeppelin is an open-source DOS counterattack tool. I am not responsible for any damages caused by this freeware program.


## Installation

Unzip and run